package com.example.studypoint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Splash Screen
        Handler H = new Handler();
        H.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent I = new Intent(MainActivity.this,LoginPage.class);
                startActivity(I);
                finish();
            }
        },2500);

        //Tittle Color
        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this,R.color.Actionbar));
    }
}