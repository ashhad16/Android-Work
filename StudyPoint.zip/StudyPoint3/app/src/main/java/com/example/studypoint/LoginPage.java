package com.example.studypoint;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {
EditText name,password;
Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        //Tittle Color
        getWindow().setStatusBarColor(ContextCompat.getColor(LoginPage.this,R.color.Actionbar));


        //Type casting enable button
//     final Button CustomButton = findViewById(R.id.btn);
//        Switch switchEnableButton = findViewById(R.id.enable);
//
//        CustomButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Toast.makeText(LoginPage.this,"Enabled",Toast.LENGTH_LONG).show();
//            }
//        });
//        switchEnableButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                if(b)
//                {
//                    CustomButton.setEnabled(true);
//                }
//                else
//                {
//                    CustomButton.setEnabled(false);
//                }
//            }
//        });


        //LoginWork

        name = findViewById(R.id.username);
        password = findViewById(R.id.passwrd);
        button = findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myname = name.getText().toString();
                String mypass = password.getText().toString();

                if(myname.equals("admin") && mypass.equals("admin"))
                {
                    Intent I = new Intent(LoginPage.this,main_page.class);
                    startActivity(I);
                }
                else
                {
                    Toast.makeText(LoginPage.this,"Invalid username or password",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}